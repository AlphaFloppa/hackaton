<?php

declare(strict_types=1);

namespace App\Service;

use App\Infrastructure\Database\ConnectionProvider;
use App\Modules\Catalog\Application\CatalogService;
use App\Modules\Order\Infrastructure\OrderRepository;
use App\Port\Routing\RoutingModuleInterface;
use App\Shared\Api\NotFoundException;
use App\Shared\Api\ValidationException;
use App\Shared\Time\Clock;

/**
 * Сервис для FrontendController: адаптер данных под форму демо-фронтенда.
 * Возвращает «плоские» структуры (без обёртки {data}), как их ждёт UI:
 * items{name,kg,vol,price}, pvz{cap,fi,fa,fis,fs,active}, заказы со статусами
 * CREATED/ASSEMBLED/ISSUED/RETURNED, остатки и уведомления.
 */
final class FrontendService
{
    /** Продавец по умолчанию для демо-фронтенда. */
    private const DEMO_SELLER_ID = '00000000-0000-0000-0000-5e1100000001';

    /** Соответствие статусов БД статусам UI фронтенда. */
    private const STATUS_MAP = [
        'RESERVED'        => 'CREATED',
        'IN_TRANSIT'      => 'ASSEMBLED',
        'DELIVERED_TO_PVZ' => 'ASSEMBLED',
        'COMPLETED'       => 'ISSUED',
    ];

    public function __construct(
        private readonly ConnectionProvider $db,
        private readonly RoutingModuleInterface $routing,
        private readonly \App\Modules\Stock\Application\SupplyService $supplies,
        private readonly CatalogService $catalog,
        private readonly Clock $clock,
    ) {}

    /**
     * Bootstrap: справочники + заказы одним ответом для первого экрана.
     * @return array<string,mixed>
     */
    public function bootstrap(): array
    {
        $pdo = $this->db->get();

        $seller = $this->fetchSeller();

        // ПВЗ в форме UI: cap/fi/fa/fis/fs/active
        $stmt = $pdo->query('SELECT * FROM pvz ORDER BY name');
        $pvz = array_map(fn (array $p): array => [
            'id' => $p['id'], 'city' => $p['city_id'], 'name' => $p['name'],
            'address' => $p['address'], 'lat' => (float) $p['lat'], 'lng' => (float) $p['lng'],
            'cap' => (int) $p['capacity_units'], 'fi' => (float) $p['fee_intake'],
            'fa' => (float) $p['fee_assembly'], 'fis' => (float) $p['fee_issue'],
            'fs' => (float) $p['fee_storage_day'], 'active' => (bool) $p['is_active'],
        ], $stmt->fetchAll(\PDO::FETCH_ASSOC));

        // Товары в форме UI: name/kg/vol/price
        $stmt = $pdo->prepare('SELECT * FROM items WHERE seller_id = ? ORDER BY sku');
        $stmt->execute([self::DEMO_SELLER_ID]);
        $items = array_map(fn (array $i): array => [
            'id' => $i['id'], 'name' => $i['title'], 'kg' => (float) $i['weight_kg'],
            'vol' => (float) $i['volume_m3'], 'price' => (float) $i['price'],
        ], $stmt->fetchAll(\PDO::FETCH_ASSOC));

        $orders = $this->orderRows('o.seller_id = ?', [self::DEMO_SELLER_ID]);

        return [
            'seller' => $seller,
            'pvz'    => $pvz,
            'items'  => $items,
            'orders' => $orders,
            ...$this->clock->status(),
        ];
    }

    /**
     * Предварительный расчёт маршрута: обе схемы в форме UI (mesh/hub с segs), источник, блокировки.
     * @param array<string,mixed> $q item_id, qty, target_pvz_id, preference
     * @return array<string,mixed>
     */
    public function quote(array $q): array
    {
        $itemId = (string) ($q['item_id'] ?? '');
        $qty = filter_var($q['qty'] ?? null, FILTER_VALIDATE_INT);
        $targetPvzId = (string) ($q['target_pvz_id'] ?? '');
        $preference = strtoupper((string) ($q['preference'] ?? 'COST'));
        if ($qty === false || $qty < 1) {
            throw new ValidationException('Количество должно быть целым числом от 1.');
        }

        $pdo = $this->db->get();
        $stmt = $pdo->prepare('SELECT * FROM items WHERE id = ?');
        $stmt->execute([$itemId]);
        $item = $stmt->fetch(\PDO::FETCH_ASSOC);
        if ($item === false) {
            throw new NotFoundException("Item $itemId not found");
        }
        return $this->routing->quote($targetPvzId, [[
            'seller_id' => $item['seller_id'], 'sku' => $item['sku'], 'qty' => $qty,
            'weight_kg' => (string) $item['weight_kg'], 'volume_m3' => (string) $item['volume_m3'],
        ]], $preference);
    }

    /** Остатки товара по ПВЗ с датой приёмки и возрастом партии. @return array<int,array<string,mixed>> */
    public function itemBatches(string $itemId): array
    {
        $stmt = $this->db->get()->prepare(
            'SELECT p.name, b.qty_available, b.qty_reserved, b.received_at
             FROM stock_batches b JOIN pvz p ON p.id = b.pvz_id
             WHERE b.item_id = ? AND b.qty_available + b.qty_reserved > 0
             ORDER BY b.received_at DESC'
        );
        $stmt->execute([$itemId]);
        $now = $this->clock->now();

        return array_map(static fn (array $b): array => [
            'pvz'            => $b['name'],
            'qty'            => (int) $b['qty_available'],
            'reserved'       => (int) $b['qty_reserved'],
            'received_at_ms' => Clock::unixMilliseconds(new \DateTimeImmutable($b['received_at'])),
            'age_days'       => Clock::wholeDaysSince($b['received_at'], $now),
        ], $stmt->fetchAll(\PDO::FETCH_ASSOC));
    }

    /** Остатки и загрузка ПВЗ в форме UI: {load, capacity, rows}. @return array<string,mixed> */
    public function pvzStock(string $pvzId): array
    {
        $pdo = $this->db->get();
        $stmt = $pdo->prepare('SELECT * FROM pvz WHERE id = ?');
        $stmt->execute([$pvzId]);
        $pvz = $stmt->fetch(\PDO::FETCH_ASSOC);
        if ($pvz === false) {
            throw new NotFoundException("PVZ $pvzId not found");
        }

        $stmt = $pdo->prepare(
            'SELECT i.title, b.qty_available, b.qty_reserved, b.received_at
             FROM stock_batches b JOIN items i ON i.id = b.item_id
             WHERE b.pvz_id = ? AND b.qty_available + b.qty_reserved > 0
             ORDER BY b.received_at DESC'
        );
        $stmt->execute([$pvzId]);
        $now = $this->clock->now();
        $rows = array_map(static fn (array $b): array => [
            'item'     => $b['title'],
            'qty'      => (int) $b['qty_available'],
            'reserved' => (int) $b['qty_reserved'],
            'age_days' => Clock::wholeDaysSince($b['received_at'], $now),
        ], $stmt->fetchAll(\PDO::FETCH_ASSOC));

        return ['load' => $this->pvzLoad($pvzId), 'capacity' => (int) $pvz['capacity_units'], 'rows' => $rows];
    }

    /** Уведомления в форме UI: [{type: ERROR|LONG_STORAGE|INFO, text, t}]. @return array<int,array<string,mixed>> */
    public function notifications(?string $pvzId): array
    {
        $sql = 'SELECT type, message, created_at FROM notifications';
        $params = [];
        if ($pvzId !== null) {
            $sql .= ' WHERE pvz_id = ?';
            $params[] = $pvzId;
        }
        $sql .= ' ORDER BY created_at DESC LIMIT 50';
        $stmt = $this->db->get()->prepare($sql);
        $stmt->execute($params);

        return array_map(fn (array $n): array => [
            'type' => match ($n['type']) {
                'INCIDENT' => 'ERROR',
                'STORAGE'  => 'LONG_STORAGE',
                default    => 'INFO',
            },
            'text' => $n['message'],
            't'    => $this->iso($n['created_at']),
        ], $stmt->fetchAll(\PDO::FETCH_ASSOC));
    }

    /**
     * Детали заказа в форме UI: chosen/cost/base/sla/history/incidents/variants/financials.
     * @return array<string,mixed>
     */
    public function orderDetails(string $orderId): array
    {
        $orders = $this->orderRows('o.id = ?', [$orderId]);
        if (!isset($orders[0])) {
            throw new NotFoundException("Order $orderId not found");
        }
        $order = $orders[0];

        $pdo = $this->db->get();

        // Варианты схем из решения маршрута
        $stmt = $pdo->prepare(
            'SELECT scheme, reason, cost_mesh, cost_hub, time_mesh, time_hub
             FROM routing_decisions WHERE order_id = ? ORDER BY created_at DESC LIMIT 1'
        );
        $stmt->execute([$orderId]);
        $d = $stmt->fetch(\PDO::FETCH_ASSOC) ?: [];

        $stmt = $pdo->prepare('SELECT is_stub, breakdown FROM order_segments WHERE order_id = ? ORDER BY seq');
        $stmt->execute([$orderId]);
        $segments = [];
        foreach ($stmt->fetchAll(\PDO::FETCH_ASSOC) as $row) {
            $segment = json_decode($row['breakdown'], true);
            if (isset($segment['n']) && $segment['n'] !== '') {
                if ($segments === [] && isset($segment['start']['n'])) {
                    $segments[] = $segment['start'];
                }
                unset($segment['start']);
                $segments[] = [...$segment, 'is_stub' => (bool) $row['is_stub']];
            }
        }

        $variants = [];
        foreach (['MESH', 'HUB_TRUNK'] as $scheme) {
            $costKey = $scheme === 'MESH' ? 'cost_mesh' : 'cost_hub';
            $timeKey = $scheme === 'MESH' ? 'time_mesh' : 'time_hub';
            $cost = isset($d[$costKey]) && $d[$costKey] !== null ? (float) $d[$costKey] : null;
            $hours = isset($d[$timeKey]) && $d[$timeKey] !== null ? (float) $d[$timeKey] : null;
            $variants[strtolower($scheme)] = [
                'scheme' => $scheme,
                'cost'   => $cost,
                'hours'  => $hours,
                'ok'     => $cost !== null,
                'why'    => $d['reason'] ?? '',
                'segs'   => $scheme === $order['chosen'] ? $segments : [],
            ];
        }

        // Начисления ПВЗ по заказу
        $stmt = $pdo->prepare(
            "SELECT entry_type, reason, CASE WHEN entry_type = 'REFUND' THEN -ABS(amount) ELSE amount END AS amount
             FROM ledger_entries WHERE order_id = ? AND pvz_id IS NOT NULL"
        );
        $stmt->execute([$orderId]);
        $feeLines = array_map(fn (array $l): array => [
            'label' => $l['reason'] ?? $l['entry_type'], 'amount' => (float) $l['amount'],
        ], $stmt->fetchAll(\PDO::FETCH_ASSOC));
        $pvzFees = array_sum(array_column($feeLines, 'amount'));

        // Инциденты
        $stmt = $pdo->prepare(
            'SELECT type, description, created_at FROM incidents WHERE order_id = ? ORDER BY created_at'
        );
        $stmt->execute([$orderId]);
        $incidents = array_map(fn (array $i): array => [
            'type' => $i['type'], 'at' => $this->iso($i['created_at']), 'detail' => $i['description'],
        ], $stmt->fetchAll(\PDO::FETCH_ASSOC));

        $status = (string) $order['status'];
        $issued = $status === 'ISSUED';
        $cost = (float) $order['cost'];

        $order['variants'] = $variants;
        $order['segs'] = $segments;
        $order['reason'] = $d['reason'] ?? $order['reason'];
        $order['incidents'] = $incidents;
        $order['financials'] = [
            'revenue'    => $issued ? $cost : 0,
            'pvz_fees'   => $pvzFees,
            'result'     => ($issued ? $cost : 0) - $cost - $pvzFees,
            'cost_lines' => [
                ['label' => 'Логистика по выбранной схеме', 'amount' => $cost],
                ...$feeLines,
            ],
        ];

        return $order;
    }

    // ── Внутренние помощники ────────────────────────────────────────────────

    /**
     * Заказы продавца/заказа в форме UI (JOIN партий, решений маршрута, SLA по городам).
     * @return array<int,array<string,mixed>>
     */
    private function orderRows(string $where, array $params): array
    {
        $sql = "SELECT o.*, b.pvz_id AS source_pvz_id, d.cost_hub, d.cost_mesh,
                       leg.from_node AS route_origin, leg.to_node AS route_first_stop,
                       (s.city_id = tp.city_id) AS same_city
                FROM orders o
                LEFT JOIN stock_batches b ON b.id = o.source_batch_id
                LEFT JOIN order_segments leg ON leg.order_id = o.id AND leg.seq = 1
                LEFT JOIN routing_decisions d ON d.order_id = o.id
                LEFT JOIN sellers s ON s.id = o.seller_id
                LEFT JOIN pvz tp ON tp.id = o.target_pvz_id
                WHERE $where
                ORDER BY o.created_at DESC LIMIT 50";
        $stmt = $this->db->get()->prepare($sql);
        $stmt->execute($params);

        return array_map(function (array $o): array {
            $base = $o['cost_hub'] ?? $o['cost_mesh'];
            return [
                'id'             => $o['id'],
                'seller'         => $o['seller_id'],
                'item'           => $o['item_id'],
                'qty'            => (int) $o['qty'],
                'target'         => $o['target_pvz_id'],
                'source_pvz_id'  => $o['source_pvz_id'] ?? OrderRepository::assemblyPoint($o),
                'status'         => self::STATUS_MAP[$o['status']] ?? $o['status'],
                'chosen'         => $o['scheme'],
                'cost'           => (float) $o['delivery_cost'],
                'base'           => $base !== null ? (float) $base : 0,
                'hours'          => (float) $o['expected_hours'],
                'sla'            => $o['same_city'] ? 24 : 72,
                'price'          => (float) $o['delivery_cost'],
                'reason'         => '',
                'created'        => $this->iso($o['created_at']),
                'history'        => [['type' => 'CREATED', 'at' => $this->iso($o['created_at'])]],
            ];
        }, $stmt->fetchAll(\PDO::FETCH_ASSOC));
    }

    /** Продавец демо (с городом) или 404. @return array{id:string,name:string,city:string|null} */
    private function fetchSeller(): array
    {
        $stmt = $this->db->get()->prepare(
            'SELECT s.id, s.name, c.name AS city
             FROM sellers s LEFT JOIN cities c ON c.id = s.city_id
             WHERE s.id = ?'
        );
        $stmt->execute([self::DEMO_SELLER_ID]);
        $seller = $stmt->fetch(\PDO::FETCH_ASSOC);
        if ($seller === false) {
            throw new NotFoundException('Demo seller not found (загрузите test/fixtures.sql)');
        }

        return $seller;
    }

    /** Занятые единицы ПВЗ (доступные + зарезервированные). */
    private function pvzLoad(string $pvzId): int
    {
        $stmt = $this->db->get()->prepare(
            "SELECT COALESCE(SUM(qty_available + qty_reserved), 0) FROM stock_batches WHERE pvz_id = ?"
        );
        $stmt->execute([$pvzId]);

        return (int) $stmt->fetchColumn();
    }

    /** Timestamp БД -> ISO 8601. */
    private function iso(string $ts): string
    {
        return (new \DateTimeImmutable($ts))->format(\DateTimeInterface::ATOM);
    }

    // ── Завозы партий (адаптер под UI) ──────────────────────────────────────

    /**
     * Создание завоза продавцом. seller_id берётся из контекста демо (DEMO_SELLER_ID).
     * @param array<string,mixed> $q item_id, pvz_id, qty
     * @return array<string,mixed>
     */
    public function createSupply(array $q, string $idempotencyKey): array
    {
        $itemId = (string) ($q['item_id'] ?? '');
        $pvzId = (string) ($q['pvz_id'] ?? '');
        $qty = (int) ($q['qty'] ?? 0);
        if ($itemId === '' || $pvzId === '' || $qty < 1) {
            throw new \App\Shared\Api\ValidationException("Fields 'item_id', 'pvz_id' (uuid) and 'qty' (int >= 1) are required");
        }

        return $this->supplies->create([
            'seller_id' => self::DEMO_SELLER_ID,
            'item_id' => $itemId,
            'pvz_id' => $pvzId,
            'qty' => $qty,
        ], $idempotencyKey);
    }

    /**
     * Приёмка завоза ПВЗ. @return array<string,mixed>
     */
    public function acceptSupply(string $supplyId, string $idempotencyKey): array
    {
        return $this->supplies->accept($supplyId, $idempotencyKey);
    }

    /**
     * Список завозов в форме UI: для продавца — свои, для ПВЗ — по pvz_id.
     * @return array<int,array<string,mixed>>
     */
    public function suppliesList(?string $pvzId): array
    {
        $sql = 'SELECT s.id, s.item_id, s.pvz_id, s.qty, s.status, s.created_at,
                       i.title AS item_name, p.name AS pvz_name, sl.name AS seller_name
                FROM supplies s
                JOIN items i ON i.id = s.item_id
                JOIN pvz p ON p.id = s.pvz_id
                JOIN sellers sl ON sl.id = s.seller_id';
        $params = [];
        if ($pvzId !== null) {
            $sql .= ' WHERE s.pvz_id = ?';
            $params[] = $pvzId;
        } else {
            $sql .= ' WHERE s.seller_id = ?';
            $params[] = self::DEMO_SELLER_ID;
        }
        $sql .= ' ORDER BY s.created_at DESC LIMIT 50';
        $stmt = $this->db->get()->prepare($sql);
        $stmt->execute($params);

        return array_map(fn (array $s): array => [
            'id' => $s['id'], 'item' => $s['item_name'], 'pvz' => $s['pvz_name'],
            'seller' => $s['seller_name'], 'qty' => (int) $s['qty'],
            'status' => $s['status'], 'created' => $this->iso($s['created_at']),
        ], $stmt->fetchAll(\PDO::FETCH_ASSOC));
    }
    /**
     * Создание товара от демо-продавца: адаптирует payload фронтенда (name/kg/vol/price)
     * к спецификационному POST /items. sku = название (уникальность через seller+sku в БД).
     * @param array<string,mixed> $body
     * @return array<string,mixed>
     */
    public function createItem(array $body): array
    {
        $name = trim((string) ($body['name'] ?? ''));
        if ($name === '') {
            throw new ValidationException("Field 'name' is required");
        }

        $item = $this->catalog->createItem(self::DEMO_SELLER_ID, [
            'sku'       => $name,
            'title'     => $name,
            'weight_kg' => $body['kg'] ?? 0,
            'volume_m3' => $body['vol'] ?? 0,
            'price'     => $body['price'] ?? 0,
        ]);

        return ['id' => $item['id'], 'name' => $name, 'price' => $item['price']];
    }

}
